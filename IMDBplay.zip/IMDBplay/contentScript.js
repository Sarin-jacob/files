
function checkStatusCode(url) {
  const xhr = new XMLHttpRequest();
  xhr.open('GET', url, true);
  xhr.onreadystatechange = function () {
    if (xhr.readyState === XMLHttpRequest.DONE) {
      if (xhr.status === 404) {
        return 404;
      } else {
        return 200;
      }
    }
  };
  xhr.send();
}


// Function to extract IMDb ID from URL
function getIMDbID(url) {
  const match = url.match(/\/tt(\d+)\//);
  return match ? match[1] : null;
}

// Find the movie title element
const movieTitleElement = document.querySelector('[data-testid="hero__primary-text"]');
if (movieTitleElement) {
  const movieTitle = movieTitleElement.innerText;
  const imdbLink = window.location.href;

  // Extract IMDb ID from the URL
  const imdbID = getIMDbID(imdbLink);

  // Create and append the icon next to the movie title
  const icon = document.createElement('img');
  // get the responce code of `https://vidsrc.to/embed/movie/tt${imdbID}`


  // Example usage:


  const rescode= checkStatusCode('https://vidsrc.to/embed/movie/tt'+imdbID);
  console.log(rescode);
  if (rescode==404) {
  icon.src = 'https://raw.githubusercontent.com/Sarin-jacob/files/main/not.png';
  }
  else { 
    icon.src = 'https://raw.githubusercontent.com/Sarin-jacob/files/main/play.png';
  }
  //icon.src = chrome.extension.getURL('https://raw.githubusercontent.com/Sarin-jacob/files/main/play.png');
  icon.style.cursor = 'pointer';
  icon.style.marginLeft = '5px';
  movieTitleElement.appendChild(icon);

  // Add click event listener to open the video player on icon click
  icon.addEventListener('click', (event) => {
    event.stopPropagation(); // Stop the event from bubbling up
    if (imdbID) {
      const videoURL = `https://vidsrc.to/embed/movie/tt${imdbID}`;
      window.open(videoURL, '_blank');
    }
  });

  // Add click event listener to open the video player on movie title click
  movieTitleElement.addEventListener('click', () => {
    if (imdbID) {
      const videoURL = `https://vidsrc.to/embed/movie/tt${imdbID}`;
      window.open(videoURL, '_blank');
    }
  });
}
