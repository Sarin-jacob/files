unzip IMDBzipPLAY.zip 
Open browser then go to extention tab by pressing manage extenstion(somewhere in the menu)
then turn on developer mode in the extenstion management page
now drag the folder 'imdb play' into the extension management page or click load extension somewhere in the page and select the 'imdb play' folder
you can now open imdb site and a icon would pop up beside the movie tile, just press it to stream the movie  