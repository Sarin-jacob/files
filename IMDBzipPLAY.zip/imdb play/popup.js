// popup.js

// Function to create the button
function createButton() {
  console.log('Attempting to create button...'); // Log to check script execution

  let primaryTextElement = document.querySelector('.hero__primary-text');
  if (primaryTextElement) {
    let button = document.createElement('button');
    button.textContent = 'Play IMDb Video';
    button.classList.add('imdbButton');

    // Event listener for button click
    button.addEventListener('click', function() {
      chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
        let imdbID = extractIMDbID(tabs[0].url);
        if (imdbID) {
          let videoURL = `https://vidsrc.to/embed/movie/tt${imdbID}`;
          console.log('Video URL:', videoURL); // Log videoURL for debugging
          chrome.tabs.create({ url: videoURL });
        } else {
          console.error('IMDb ID not found on this page.'); // Log error for debugging
        }
      });
    });

    // Get the div containing the IMDb title
    let imdbTitleDiv = findIMDbTitleDiv();

    // Insert the button within the IMDb title div
    if (imdbTitleDiv) {
      imdbTitleDiv.appendChild(button);
      console.log('Button created successfully.'); // Log success for debugging
    } else {
      console.error('IMDb title div not found.'); // Log error for debugging
    }
  } else {
    console.error('IMDb primary text element not found.'); // Log error for debugging
  }
}

// Function to find the div containing the IMDb title
function findIMDbTitleDiv() {
  let titleDiv = document.querySelector('.hero');
  if (titleDiv) {
    return titleDiv;
  }
  return null;
}

// Function to extract IMDb ID from URL
function extractIMDbID(url) {
  let match = url.match(/\/tt(\d+)\//);
  return match ? match[1] : null;
}

// Create the button when the DOM content is loaded
console.log('Content script running on IMDb page... by sree'); // Log to check script execution
createButton(); // Attempt to create
