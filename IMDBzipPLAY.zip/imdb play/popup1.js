// popup.js
document.addEventListener("DOMContentLoaded", function () {
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    chrome.tabs.sendMessage(tabs[0].id, { message: "clicked_browser_action" }, function (response) {
      if (response && response.imdbID) {
        const imdbID = response.imdbID;
        const videoURL = `https://vidsrc.to/embed/movie/tt${imdbID}`;
        const movieTitle = document.getElementById("movieTitle");
        const playIcon = document.getElementById("playIcon");

        movieTitle.addEventListener("click", function () {
          window.open(videoURL);
        });

        playIcon.addEventListener("click", function () {
          window.open(videoURL);
        });
      }
    });
  });
});
